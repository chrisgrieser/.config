// ==UserScript==
// @name        Discord Open-in-App
// @namespace   Violentmonkey Scripts
// @match       https://discord.com/*
// @version     1.0
// @author      pseudometa
// @description 9/7/2023, 11:10:36 AM
// @icon        https://cdn3.iconfinder.com/data/icons/popular-services-brands-vol-2/512/discord-512.png
// ==/UserScript==

// INFO needs "always open link with Discord" to be confirmed once

// redirection
const originalURL = document.URL;
const redirectedURL = originalURL
	.replace(/https(:\/\/discord.com\/channels\/\d+\/\d+\/\d+)/, "discord$1");

window.location.href = (redirectedURL);
window.close(); // close leftover tab
