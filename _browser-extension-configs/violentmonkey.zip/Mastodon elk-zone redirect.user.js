// ==UserScript==
// @name        Mastodon elk-zone redirect
// @namespace   Violentmonkey Scripts
// @match       *://mastodon.social/*
// @match       *://mstdn.social/*
// @match       *://press.coop/*
// @exclude     *://*/*/*#.
// @version     1.0
// @author      pseudometa
// @description 09/07/2023, 10:59:03
// @icon        https://upload.wikimedia.org/wikipedia/commons/thumb/4/48/Mastodon_Logotype_%28Simple%29.svg/1200px-Mastodon_Logotype_%28Simple%29.svg.png
// ==/UserScript==

const myMastodonInstance = "pkm.social";

const originalURL = document.URL;
const redirectedURL = originalURL
	.replace(/https:\/\/(.*?)\/(@.*)/, `https://elk.zone/${myMastodonInstance}/$2@$1`)

window.location.href = (redirectedURL);