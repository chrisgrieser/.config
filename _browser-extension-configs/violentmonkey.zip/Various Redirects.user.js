// ==UserScript==
// @name        Various Redirects
// @namespace   Violentmonkey Scripts
// @match       https://*.fandom.com/*
// @version     1.0
// @author      pseudometa
// @description redirects fandom wikis to breezewiki
// @icon        https://gitdab.com/cadence/breezewiki/raw/branch/main/static/breezewiki-favicon.svg
// ==/UserScript==

// https://libredirect.github.io/

const originalURL = document.URL
const redirectedURL = originalURL
	.replace(/https?:\/\/(.*?)\.fandom\.com\/(.*)/, "https://breezewiki.com/$1/$2") // https://regex101.com/r/KwitX9/1


window.location.href = (redirectedURL);