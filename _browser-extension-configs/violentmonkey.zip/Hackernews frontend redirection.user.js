// ==UserScript==
// @name        Hackernews frontend redirection
// @namespace   Violentmonkey Scripts
// @match       https://news.ycombinator.com/item/*
// @version     1.0
// @author      pseudometa
// @description 18/07/2023, 11:34:16
// @icon        https://news.ycombinator.com/favicon.ico
// ==/UserScript==

// redirection
const originalURL = document.URL
const redirectedURL = originalURL
	.replace(/https:\/\/news.ycombinator.com\/item\?id=(\d+)/, "https://dstill.ai/hackernews/item/$1")

window.location.href = (redirectedURL);
