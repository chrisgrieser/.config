// ==UserScript==
// @name        devdocs to source pages redirect
// @namespace   Violentmonkey Scripts
// @match       https://devdocs.io/*
// @version     1.0
// @author      pseudometa
// @description 9/22/2024, 4:47:40 AM
// @icon        https://devdocs.io/images/apple-icon-144.png
// ==/UserScript==

const originalSites = {
	css: "https://developer.mozilla.org/en-US/docs/Web/CSS/",
	javascript: "https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/",
	html: "https://developer.mozilla.org/en-US/docs/Web/HTML/",
	dom: "https://developer.mozilla.org/en-US/docs/Web/API/",
	jsdoc: "https://jsdoc.app/",
	typescript: "https://www.typescriptlang.org/",
	electron: "https://www.electronjs.org/docs/latest/",
	python: "https://docs.python.org/{{version}}/",
	git: "https://git-scm.com/docs/",
	lua: "https://www.lua.org/manual/{{version}}/manual.html",
	hammerspoon: "https://www.hammerspoon.org/docs/",
	browser_support_tables: "https://caniuse.com/",
	node: "https://nodejs.org/api/",
	moment: "https://momentjs.com/docs/#/",
	npm: "https://docs.npmjs.com/",
	jq: "https://jqlang.github.io/jq/manual/v1.7/index.html#"
}

let [_, topic, version, site] = document.URL.match(/.*devdocs.io\/([^\/~]*)(?:~(.*?))?\/(.+)/) || [];
let sourcePage = originalSites[topic];
if (sourcePage) {
	if (version) sourcePage = sourcePage.replace("{{version}}", version);

	if (topic === "lua") site = site.replace("index", "");
	if (topic === "node") site = site.replace("#", ".html#");
	if (topic === "moment") site = site.replace("index#/", "");

	window.location.href = sourcePage + site;
}
