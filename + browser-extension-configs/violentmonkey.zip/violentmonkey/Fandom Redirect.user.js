// ==UserScript==
// @name        Fandom Redirect
// @namespace   Violentmonkey Scripts
// @match       https://*.fandom.com/*
// @version     1.0
// @author      pseudometa
// @description redirects fandom wikis
// @icon        https://gitdab.com/cadence/breezewiki/raw/branch/main/static/breezewiki-favicon.svg
// ==/UserScript==

const originalURL = document.URL
const redirectedURL = originalURL
	.replace(/https?:\/\/(.*?)\.fandom\.com\/(.*)/, "https://antifandom.com/$1/wiki/$2")
	// .replace(/https?:\/\/(.*?)\.fandom\.com\/(.*)/, "https://breezewiki.com/$1/$2")

window.location.href = (redirectedURL);