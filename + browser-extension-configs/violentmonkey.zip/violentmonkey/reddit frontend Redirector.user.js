// ==UserScript==
// @name        reddit frontend Redirector
// @namespace   Violentmonkey Scripts
// @icon         https://www.redditstatic.com/desktop2x/img/favicon/android-icon-192x192.png
// @match        https://www.reddit.com/r/*
// @match        https://old.reddit.com/r/*
// @version     1.0
// @author      pseudometa
// @description 5/3/2024, 2:07:00 PM
// ==/UserScript==

const redirectedURL = document.URL.replace(/(www|old)\.reddit\.com/, "new.reddit.com");
window.location.href = (redirectedURL);
