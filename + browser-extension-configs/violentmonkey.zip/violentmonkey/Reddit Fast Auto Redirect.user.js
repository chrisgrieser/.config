// ==UserScript==
// @name         Reddit Fast Auto Redirect
// @namespace    Violentmonkey Scripts
// @version      0.8
// @description  Auto-redirect traffic from www.reddit.com to new.reddit.com before the page loads
// @run-at       document-start
// @match        *://www.reddit.com/*
// @match        *://old.reddit.com/*
// @match        *://sh.reddit.com/*
// @exclude      *://www.reddit.com/media*
// @grant        none
// ==/UserScript==

// SOURCE https://greasyfork.org/en/scripts/487801-reddit-fast-auto-redirect

const hostname = location.hostname;
window.location.replace(window.location.href.replace(hostname, 'new.reddit.com'));
