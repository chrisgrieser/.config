// ==UserScript==
// @name         Reddit Fast Auto Redirect
// @namespace    Violentmonkey Scripts
// @version      1.0
// @icon         https://www.redditstatic.com/desktop2x/img/favicon/android-icon-192x192.png
// @description  Auto-redirect traffic from www.reddit.com to new.reddit.com before the page loads
// @run-at       document-start
// @match        *://www.reddit.com/*
// @match        *://old.reddit.com/*
// @match        *://sh.reddit.com/*
// @exclude      *://www.reddit.com/media*
// @exclude      *://www.reddit.com/chat*
// @exclude      *://www.reddit.com/prefs*
// @grant        none
// ==/UserScript==

// SOURCE https://greasyfork.org/en/scripts/487801-reddit-fast-auto-redirect

const hostname = location.hostname;
window.location.replace(window.location.href.replace(hostname, 'new.reddit.com'));
