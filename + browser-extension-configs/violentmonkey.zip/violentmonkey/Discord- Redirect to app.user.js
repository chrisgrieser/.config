// ==UserScript==
// @name        Discord: Redirect to app
// @namespace   Violentmonkey Scripts
// @match       https://discord.com/channels/*
// @version     1.0
// @author      pseudometa
// @description 15/08/2023, 09:39:30
// @icon        https://logodownload.org/wp-content/uploads/2017/11/discord-logo-1-1.png
// ==/UserScript==


// INFO needs "always open link with Discord" to be confirmed once


const originalURL = document.URL;
const redirectedURL = originalURL
	.replace(/https(:\/\/discord.com\/channels\/\d+\/\d+\/\d+)/, "discord$1");

window.location.href = (redirectedURL);
window.close(); // close leftover tab
