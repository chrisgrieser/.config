// ==UserScript==
// @name        Redirect to Mastodon home instance
// @namespace   Violentmonkey Scripts
// @match       https://*/@*/*#.
// @version     1.0
// @author      pseudometa
// @description 2024-11-22
// @icon        https://mastodon.social/packs/media/icons/favicon-48x48-c1197e9664ee6476d2715a1c4293bf61.png
// ==/UserScript==

// CONFIG
const HOME_INSTANCE = "pkm.social";

//======================================================================================================

const url = window.location.href;
window.location.href = `https://${HOME_INSTANCE}/authorize_interaction?uri=${encodeURIComponent(url)}`;
//======================================================================================================

/* Violentmonkey gives a warning:
> "#" patterns work only when initially opening the site or reloading the tab: https://*/@*/*#.
However, since script only does a  simple redirect, this is fine.*/