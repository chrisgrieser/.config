// ==UserScript==
// @name         GitHub: remove `?tab=readme-ov-file` from URL
// @description  GitHub: remove `?tab=readme-ov-file` from URL
// @namespace    https://gist.github.com/vogler
// @downloadURL  https://gist.github.com/vogler/74edff6de37c3a13eeff8c99c6bed910/raw/clean-url-readme-tab.github.com.tamper.js
// @version      0.1
// @author       Ralf Vogler
// @match        https://github.com/*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=github.com
// @grant        none
// ==/UserScript==

// @match https://github.com/*?tab=readme-ov-file* is not enough since we want to detect changes without reload

// see https://github.com/orgs/community/discussions/70577

(function() {
    'use strict';

    const rewrite = () => location.search == '?tab=readme-ov-file' && (console.log('rewrite', location.href) || history.replaceState({}, null, location.href.replace(location.search, '')));
    window.onpopstate = rewrite; // on navigation
    rewrite(); // on initial load
})();