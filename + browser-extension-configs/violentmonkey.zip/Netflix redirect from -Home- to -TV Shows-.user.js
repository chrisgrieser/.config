// ==UserScript==
// @name        Netflix redirect from "Home" to "TV Shows"
// @namespace   Violentmonkey Scripts
// @match       https://www.netflix.com/browse
// @version     1.0
// @author      pseudometa
// @description 2025-03-09
// @icon        https://www.netflix.com/favicon.ico
// ==/UserScript==

// REASON
// the Netflix PWA always opens Netflix at "Home", but I prefer it to open
// at "TV Shows", since I am not interested in games/movies suggested at the "Home" tab.

window.location.href = "https://www.netflix.com/browse/genre/83"
