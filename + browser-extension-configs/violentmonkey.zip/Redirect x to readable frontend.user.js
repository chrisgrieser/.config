// ==UserScript==
// @name        Redirect x to readable frontend
// @namespace   Violentmonkey Scripts
// @match       *://x.com/*
// @version     1.0
// @author      pseudometa
// @description 2024-11-13
// @icon        https://x.com/favicon.ico
// ==/UserScript==

// simple redirect
window.location.href = window.location.href.replace(/x\.com/, "xcancel.com");

