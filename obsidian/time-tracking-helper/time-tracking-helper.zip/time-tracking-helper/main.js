// @ts-nocheck // using pure javascript without the whole toolchain here
//──────────────────────────────────────────────────────────────────────────────

function prettyHours(minutes) {
	let hh = (minutes / 60).toFixed(2);
	if (hh.endsWith(".00")) hh = hh.slice(0, -3);  // 3.00
	if (hh.endsWith("0")) hh = hh.slice(0, -1);  // 3.50
	return hh.replace(".", ",") + "h"
}

function lineToReport(editor) {
	const cursor = editor.getCursor("from");
	const currentLine = editor.getLine(cursor.line);

	// example line: 9:00-11:00 Arbeit, 12:00-15:30 Orga
	const timePattern = /(\d{1,2}[:.]\d{2})-(\d{1,2}[:.]\d{2}) ([\wÄÖÜäöü]+)/;

	// parse activities
	const activities = currentLine
		.match(new RegExp(timePattern, "g"))
		?.reduce((acc, activity) => {
			const [_, start, end, type] = activity.match(timePattern);
			let [startHH, startMM] = start.split(/[:.]/).map(Number);
			const [endHH, endMM] = end.split(/[:.]/).map(Number);
			if (startHH > endHH) startHH -= 24; // time beyond midnight

			const duration = (endHH * 60 + endMM) - (startHH * 60 + startMM);
			acc[type] = (acc[type] ?? 0) + duration;
			return acc;
		}, {}) ?? false;
	if (!activities) {
		new Notice("Paragraph does not contain any activities in the expected format.");
		return;
	}

	// create report callout
	const reportLines = []
	let totalMins = 0
	for (const [type, durationMins] of Object.entries(activities)) {
		totalMins += durationMins;
		reportLines.push(`> - ${type}: ${prettyHours(durationMins)}`);
	}
	reportLines.push(`> - **Total**: ${prettyHours(totalMins)}`);
	const report = "> [!TODO] Report\n" + reportLines.join("\n") + "\n";
	const insertAt = { line: cursor.line + 1, ch: 0 } // below current line
	editor.replaceRange(report, insertAt);

	// praise notification 💪
	const praiseThresholdHours = 6;
	if (totalMins > 60 * praiseThresholdHours) {
		const msg = `Ganze ${prettyHours(totalMins)} heute!`
			+ "\n\nChris ist stolz auf Dich! 💪"
		new Notice(msg, 10000);
	}
}

//──────────────────────────────────────────────────────────────────────────────

class TimeTrackingHelperPlugin extends require("obsidian").Plugin {
	onload() {
		console.info(this.manifest.name + " loaded.");

		this.addCommand({
			id: "line-to-report",
			name: "Convert line to report",
			icon: "clipboard-clock", // for mobile
			editorCallback: (editor) => lineToReport(editor),
		});
	}
}

//──────────────────────────────────────────────────────────────────────────────
module.exports = TimeTrackingHelperPlugin;
