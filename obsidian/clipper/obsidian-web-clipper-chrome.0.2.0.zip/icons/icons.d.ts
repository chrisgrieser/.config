import { IconNode } from 'lucide';

export const icons: Record<string, IconNode>;
export function initializeIcons(root?: HTMLElement | Document): void;